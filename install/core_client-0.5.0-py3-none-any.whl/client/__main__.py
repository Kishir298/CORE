from .core_device_client import main

if __name__ == "__main__":
    raise SystemExit(main())
